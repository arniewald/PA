import java.awt.Color;
import java.awt.Graphics;

public class Asuka extends Nau{
	
	int feliços_dijous;
	Joc j;
	
	Asuka(Joc j){
		super(50,350,0,0,50,50,5,"asuka.png");
		feliços_dijous=0;
		this.j=j;
	}
	
	public void aturar() {
		v_x=0;
		v_y=0;
	}
	
	public Projectil disparar() {
		Projectil projectil=new Projectil(x+ample+1,y+(int)alt/2-10/2,20,0,this);
		return projectil;
	}
	
	public FeliçDijous desitjarFeliçDijous() {
		FeliçDijous feliçdijous = new FeliçDijous(x+ample+1,y);
		return feliçdijous;
	}
	
	@Override
	void moure() {
		if ((x<=0 && v_x<0) ||(x+ample>=Finestra.AMPLADA && v_x>0)) {}
		else x+=v_x;
		if ((y<=j.p.alt+15 && v_y<0) ||(y+alt>=Finestra.ALÇADA && v_y>0)) {}
		else y+=v_y;
	}

	@Override
	void reaccionaColisio(Nau nau) {
		if (nau instanceof PetitaAsuka) feliços_dijous++;
		else if (nau instanceof Vida && vida<10) vida++;
		/*else if (nau instanceof Projectil) vida--;
		else vida-=3;*/
		
	}
	
	void pintarBarraVida(Graphics g) {
		g.setColor(Color.green);
		g.fillRect(x, y-10, vida*(int)(ample/10), 5);
		g.setColor(Color.black);
		g.fillRect(x+vida*(int)(ample/10), y-10, ample-vida*(int)(ample/10), 5);
	}
	
	@Override
	void pintar(Graphics g) {
		super.pintar(g);
		pintarBarraVida(g);
	}

}
