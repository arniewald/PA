import java.awt.Graphics;
import java.awt.Image;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public abstract class Nau{
	int x, y, v_x, v_y;
	int ample, alt;
	int vida;
	Image imatge;
	
	Nau(int x,int y,int v_x, int v_y, int ample,int alt,int vida, String nom_fitxer){
		this.x = x;
		this.y = y;
		this.v_x=v_x;
		this.v_y=v_y;
		this.ample=ample;
		this.alt=alt;
		this.vida=vida;
		try {
			imatge=ImageIO.read(new File(nom_fitxer));
		} catch (IOException e) {
		}
	}

	abstract void moure();
	
	abstract void reaccionaColisio(Nau nau);
	
	void escriuCoordenades() {
		System.out.println("("+this.x + ","+this.y+")" + "("+this.x + ","+(this.y+this.alt)+")" + "("+(this.x+this.ample) + ","+(this.y+this.alt)+")" + "("+(this.x+this.ample) + ","+this.y+")");
	}
	
	void pintar(Graphics g) {
		g.drawImage(imatge,x,y,ample,alt,null);
	}
}
