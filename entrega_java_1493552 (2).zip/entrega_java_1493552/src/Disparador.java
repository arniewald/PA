public class Disparador extends Nau implements Disparable{
	

	int comptador;
	Asuka objectiu;
	int fase;
	
	Disparador(Asuka objectiu, int x, int y, int fase){
		super(x,y,-3,3,50,50,3,"disparador.png");
		this.comptador=0;
		this.objectiu=objectiu;
		this.fase=fase;
	}

	@Override
	void moure() {
		x+=v_x;
		if (fase==5) {
			if (y<(int)(900/5)+20) v_y=3;
			if (y+alt>Finestra.ALÇADA) v_y=-3;
		}
		else {
			v_y=0;
			if (x<=Finestra.AMPLADA*0.9) v_x=0;
		}
		y+=v_y;
		
	}

	@Override
	void reaccionaColisio(Nau nau) {
		if (nau instanceof Asuka || (nau instanceof Projectil && ((Projectil) nau).origen instanceof Asuka)) {
			vida--;		
		}	
	}
	
	@Override
	public Projectil disparar() {
		double x, y;
		double dist_x=objectiu.x+(double)(objectiu.ample/2)-this.x-(double)(ample/2);
		double dist_y=objectiu.y+(double)(objectiu.alt/2)-this.y-(double)(alt/2);
		double dist=Math.sqrt(dist_x*dist_x+dist_y*dist_y);
		double pendent=dist_y/dist_x;
		double oo=(int)(this.y+alt/2)-pendent*(int)(this.x+ample/2);
		double pendent_disp=alt/ample;
		if (Math.abs(pendent_disp)>Math.abs(pendent)) {
			if (dist_x>0) {
				x=this.x+ample+1;
				y=pendent*x+oo;
			}
			else {
				x=this.x-1;
				y=pendent*x+oo;
			}
		}
		else {
			if (dist_y>0) {
				y=this.y+alt+1;
				x=(y-oo)/pendent;
			}
			else {
				y=this.y-1;
				x=(y-oo)/pendent;
			}
		}
		return new Projectil((int)x,(int)y, (int)(20*dist_x/dist),(int)(20*dist_y/dist),this);
	}

	@Override
	public boolean comptar() {
		double dist_x=objectiu.x+(double)(objectiu.ample/2)-this.x-(double)(ample/2);
		if (fase==5 && dist_x*dist_x>30625 ) return false;
		if (comptador<20) {
			comptador++;
			return false;
		}
		else {
			comptador=0;
			return true;
		}
	}
}