
public class Rei extends Nau{
	
	int felicitat;
	
	Rei(int x, int y){
		super(x,y,-1,0,50,50,3,"rei.jpg");
		felicitat=0;
	}

	@Override
	void moure() {
		if (x>=(int)(Finestra.AMPLADA*0.95)) x+=v_x;
	}

	@Override
	void reaccionaColisio(Nau nau) {
		if (nau instanceof FeliçDijous) felicitat++;
		
	}

}
