public class Reflector extends Nau{
	
	Reflector(int x, int y){
		super(x,y,-2,0,50,50,1, "reflector.png");
	}

	@Override
	void moure() {
		x+=v_x;
	}
	

	@Override
	void reaccionaColisio(Nau nau) {
		if (nau instanceof Asuka) vida=0; 
	}
	
}
