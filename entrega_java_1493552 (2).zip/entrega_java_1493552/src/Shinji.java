
public class Shinji extends Nau{
	
	int felicitat;
	
	Shinji(){
		super(Finestra.AMPLADA,(int)(Finestra.ALÇADA/2),-1,0,100,100,3,"shinji.png");
		felicitat=0;
	}

	@Override
	void moure() {
		if (x<=Finestra.AMPLADA*0.9) v_x=0;
		x+=v_x;
		
	}

	@Override
	void reaccionaColisio(Nau nau) {
		if (nau instanceof FeliçDijous) {
			felicitat++;
		}
		
	}

}
