public class Enemic extends Nau implements Disparable{

	int comptador;
	int trigger;
	
	Enemic(int x, int y){
		super(x,y, -3,0,70,50,3, "enemic.png");
		comptador=0;
		trigger=40;
	}

	@Override
	void moure() {
		x+=v_x;
		y+=v_y;
	}

	@Override
	void reaccionaColisio(Nau nau) {
		if  (nau instanceof Projectil && ((Projectil) nau).origen instanceof Asuka) {
			vida--;
		}
		if (nau instanceof Asuka) vida=0;
	}
	
	@Override
	public boolean comptar() {
		if (comptador<trigger) {
			comptador++;
			return false;
		}
		else {
			comptador=0;
			return true;
		}
	}
	
	@Override
	public Projectil disparar() {
		Projectil projectil=new Projectil(x-1,y+(int)alt/2-10/2,-10,0,this);
		return projectil;
	}
	
}
