import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.imageio.ImageIO;

public class Ranquing implements MouseListener{
	Finestra f;
	Image ranquing, sortir;
	
	Ranquing(Finestra f) throws Exception{
		this.f=f;
		try {
			ranquing=ImageIO.read(new File("ranquing.png"));
			sortir=ImageIO.read(new File("sortir.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		f.addMouseListener(this);
		f.g.drawImage(ranquing,0,0,Finestra.AMPLADA,Finestra.ALÇADA,null);
		f.g.drawImage(sortir, (int)(Finestra.AMPLADA*0.93), (int)(Finestra.ALÇADA*0.07), 50, 50, null);
		f.g.drawImage(ranquing,0,0,Finestra.AMPLADA,Finestra.ALÇADA,null);
		f.g.drawImage(sortir, (int)(Finestra.AMPLADA*0.93), (int)(Finestra.ALÇADA*0.07), 50, 50, null);
		f.g.setFont(new Font("Consolas", Font.PLAIN, 20));
		ordenaPuntuacions();
		ordenaTemps();
	}
	
	void ordenaPuntuacions() throws Exception  {
		f.g.setColor(Color.red);
		f.g.drawString("Jugadora",400,300);
		f.g.drawString("Puntuació",700,300);
		f.g.drawString("Temps",1000,300);
		Connection con;
		con=DriverManager.getConnection("jdbc:sqlite:partides.db");
		Statement smt=con.createStatement();
		String q="SELECT * FROM partides ORDER BY puntuacio DESC LIMIT(5)";
		ResultSet rs=smt.executeQuery(q);
		int y=0;
		f.g.setColor(Color.black);
		while(rs.next()) {
			f.g.drawString(rs.getString("jugadora"),400,340+30*y);
			f.g.drawString(Integer.toString(rs.getInt("puntuacio")),700,340+30*y);
			f.g.drawString(Integer.toString(rs.getInt("Temps")),1000,340+30*y);
			y++;
		}
	}
	
	void ordenaTemps() throws Exception  {
		f.g.setColor(Color.red);
		f.g.drawString("Jugadora",400,550);
		f.g.drawString("Puntuació",700,550);
		f.g.drawString("Temps",1000,550);
		Connection con;
		con=DriverManager.getConnection("jdbc:sqlite:partides.db");
		Statement smt=con.createStatement();
		String q="SELECT * FROM partides ORDER BY temps LIMIT(5)";
		ResultSet rs=smt.executeQuery(q);
		int y=0;
		f.g.setColor(Color.black);
		while(rs.next()) {
			f.g.drawString(rs.getString("jugadora"),400,590+30*y);
			f.g.drawString(Integer.toString(rs.getInt("puntuacio")),700,590+30*y);
			f.g.drawString(Integer.toString(rs.getInt("Temps")),1000,590+30*y);
			y++;
		}
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		int x=e.getX();
		int y=e.getY();
		if (x>=(int)(Finestra.AMPLADA*0.93) && x<=(int)(Finestra.AMPLADA*0.93)+50 && y>=(int)(Finestra.ALÇADA*0.07) && y<=(int)(Finestra.ALÇADA*0.07)+50) {
			f.pantalla=0;
			f.removeMouseListener(this);
		}
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

}