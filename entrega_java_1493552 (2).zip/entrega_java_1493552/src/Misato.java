public class Misato extends Nau {
	
	public int felicitat;
	public boolean aturada;
	
	Misato(int x, int y) {
		super(x,y,-1,3,50,50,10,"misato.jpg");
		felicitat=0;
	}

	@Override
	void moure() {
		if (!aturada) {
			if (felicitat<6) {
				if (x>1400) x+=v_x;
				if (y>800) v_y=-3;
				if (y<200) v_y=3;
				y+=v_y;
			}
			else {
				v_y=0;
				x+=v_x;
			}
		}
	}

	@Override
	void reaccionaColisio(Nau nau) {
		if (nau instanceof FeliçDijous) felicitat++;
	}
	
}
