
public class PetitaAsuka extends Nau{

	PetitaAsuka(int x,int y){
		super(x,y,-2,0,40,50,1,"petita_asuka.png");
	}

	@Override
	void moure() {
		x+=v_x;
		y+=v_y;
	}

	@Override
	void reaccionaColisio(Nau nau) {
		if (nau instanceof Asuka) {
			vida--;
		}
	}
	
}
