
public class Vida extends Nau {

	Vida(int x, int y) {
		super(x, y, -3, 0, 20, 20, 1,  "vida.png");
		// TODO Auto-generated constructor stub
	}

	@Override
	void moure() {
		x+=v_x;
	}

	@Override
	void reaccionaColisio(Nau nau) {
		if (nau instanceof Asuka) {
			vida--;
		}
	}

}
