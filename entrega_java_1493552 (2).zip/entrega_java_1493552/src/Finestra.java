import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Image;

import javax.swing.JFrame;

public class Finestra extends JFrame{
	Joc j;
	MenuPrincipal m;
	Instruccions ins;
	Ranquing r;
	Image im;
	Graphics g;
	final static int ALÇADA=800,AMPLADA=1500;
	int pantalla;
	
	public static void main(String[] args) throws Exception {
		new Finestra();
		
	}
	
	Finestra() throws Exception {
		super("Joc");
		setLayout(new FlowLayout());
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(AMPLADA,ALÇADA);
		setVisible(true);
		im=createImage(AMPLADA,ALÇADA);
		g=im.getGraphics();
		pantalla=0;
		j=null;
		m=null;
		ins=null;
		r=null;
		while(true) {
			if (pantalla==0) {
				if (j!=null) j=null;
				if (ins!=null) ins=null;
				if (r!=null) r=null;
				if (m==null) m=new MenuPrincipal(this);
			}
			if (pantalla==1) {
				if (m!=null) m=null;
				if (j==null) j=new Joc(this);
				j.run();
			}
			if (pantalla==2) {
				if (m!=null) m=null;
				if (ins==null) ins=new Instruccions(this);
			}
			if (pantalla==3) {
				if (m!=null) m=null;
				if (r==null) r=new Ranquing(this);
			}
			repaint();
		}
	}
	
	public void paint(Graphics g) {
		g.drawImage(im, 0, 0, null);
	}
	public void update(Graphics g) {
		paint(g);
	}
}
