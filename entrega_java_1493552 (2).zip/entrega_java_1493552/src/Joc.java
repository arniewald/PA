import java.awt.Image;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

public class Joc implements KeyListener{
	Finestra f;
	PanellDeControl p;
	Clip musica;
	Image fons;
	Random rng;
	int estat;
	int t;
	int fons_x;
	int fons_y;
	int puntuacio;
	int temps;
	int fase;
	boolean alerta;
	ArrayList<ArrayList<Nau>> naus = new ArrayList<ArrayList<Nau>>();
	ArrayList<Nau> asukes = new ArrayList<Nau>();
	ArrayList<Nau> enemics = new ArrayList<Nau>();
	ArrayList<Nau> reflectors = new ArrayList<Nau>();
	ArrayList<Nau> clons = new ArrayList<Nau>();
	ArrayList<Nau> disparadors = new ArrayList<Nau>();
	ArrayList<Nau> gegants = new ArrayList<Nau>();
	ArrayList<Nau> misatos = new ArrayList<Nau>();
	ArrayList<Nau> reis = new ArrayList<Nau>();
	ArrayList<Nau> shinjis = new ArrayList<Nau>();
	ArrayList<Nau> projectils = new ArrayList<Nau>();
	ArrayList<Nau> petitesasukes = new ArrayList<Nau>();
	ArrayList<Nau> feliçosdijous = new ArrayList<Nau>();
	ArrayList<Nau> vides = new ArrayList<Nau>();
	Asuka asuka=new Asuka(this);
	Misato misato;
	Rei rei;
	Shinji shinji;
	GuardaPartida gp;
	
	Joc(Finestra f) {
		this.f=f;
		f.addKeyListener(this);
		this.p=new PanellDeControl(this);
		try {
			fons=ImageIO.read(new File("fons_repte.jpg"));
		} catch (IOException e) {
			System.out.println("Oupsie daisy");
		}
		rng=new Random();
		fons_x=0;
		fons_y=0;
		alerta=false;
		misato=new Misato(Finestra.AMPLADA,Finestra.ALÇADA);
		rei= new Rei(Finestra.AMPLADA,(int)(Finestra.ALÇADA*0.825));
		shinji=null;
		asukes.add(asuka);
		naus.add(asukes);
		naus.add(misatos);
		naus.add(reis);
		naus.add(shinjis);
		naus.add(projectils);
		naus.add(enemics);
		naus.add(reflectors);
		naus.add(clons);
		naus.add(disparadors);
		naus.add(gegants);
		naus.add(petitesasukes);
		naus.add(feliçosdijous);
		naus.add(vides);
	}
	
	
	public void run() {
		estat=0;
		fase=1;
		t=0;
		try {
	            musica = AudioSystem.getClip();
	            musica.open(AudioSystem.getAudioInputStream(new File("musica_joc.wav")));
	            musica.loop(Clip.LOOP_CONTINUOUSLY);
	            while (musica.isRunning()) Thread.sleep(5);
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
		int temps_sleep=50;
		while(f.pantalla==1) {
			if (estat==0) {
				if (!musica.isRunning()) musica.start();
				if (fase==1) {
					t++;
					if (t>=120*1000/50) {
						if (enemics.size()!=0) {}
						else {
							fase=2;
							t=0;
						}
					}
					else aplicaNivell1(t);
				}
				if (fase==2) {
					t++;
					aplicaNivell2(t);
					if (misato.felicitat>=1) {
						misatos.remove(misatos.size()-1);
						for (Nau enemic: enemics) {
							enemic.v_y=0;
							enemic.v_x=-3;
						}
						fase=3;
						t=0;
					}
					if (misatos.size()!=0 && misato.felicitat<1 && asuka.feliços_dijous==0 && petitesasukes.size()==0 && feliçosdijous.size()==0) {
						estat=1;
					}
				}
				if (fase==3) {
					t++;
					if (t>=120*1000/50) {
						if (enemics.size()!=0 || clons.size()!=0 || reflectors.size()!=0) {}
						else{
							fase=4;
							t=0;
						}
					}
					else aplicaNivell3(t);
					
				}
				if (fase==4) {
					if (t==0) reis.add(rei);
					t++;
					if (rei.felicitat>=2) {
						reis.remove(rei);
					}
					if (reis.size()==0) {
						if (enemics.size()!=0 || clons.size()!=0 || reflectors.size()!=0) {}
						else {
							fase=5;
							t=0;
						}
					}
					else aplicaNivell4(t);
				}
				if (fase==5) {
					t++;
					if (t>=120*1000/50) {
						if (disparadors.size()!=0 || reflectors.size()!=0) {}
						else {
							fase=6;
							t=0;
						}
					}
					else aplicaNivell5(t);
				}
				if (fase==6) {
					t++;
					if (shinji!=null && shinji.felicitat>=3) {
						musica.close();
						try {
				            musica.open(AudioSystem.getAudioInputStream(new File("victoria.wav")));
				            musica.start();
				            while (musica.isRunning()) Thread.sleep(5);
				        } catch (Exception e) {
				            e.printStackTrace();
				        }
						estat=4;
						gp = new GuardaPartida(puntuacio,temps);
					}
					aplicaNivell6(t);
				}
				
				alerta=true;
				dispara();
				moureElements();
				detectaColisions();
				if (asuka.vida<=0) estat=1;
				repintaPantalla();
				alerta=false;
				temps+=temps_sleep;
			}
			else {
				if (estat!=4) musica.stop();
				f.removeKeyListener(this);
			}
			try {
				Thread.sleep(temps_sleep);
			} catch (InterruptedException e) {
			}
		}
		musica.close();
	}
	
	void reinicialitzacio() {
		asuka.vida=5;
		asuka.x=50;
		asuka.y=350;
		asuka.v_x=0;
		asuka.v_y=0;
		for (ArrayList<Nau> llista: naus) {
			if (llista!=asukes) llista.removeAll(llista);
		}
		t=0;
	}
	
	void aplicaNivell1(int t) {
		if (t%20==0) {
			int tipus_enemic=rng.nextInt(100);
			if (tipus_enemic<50) {
				reflectors.add(new Reflector(Finestra.AMPLADA,p.alt+20+rng.nextInt(Finestra.ALÇADA-p.alt-20)));
			}
			
			else if (40<=tipus_enemic && tipus_enemic<95) {
				enemics.add(new Enemic(Finestra.AMPLADA,p.alt+20+rng.nextInt(Finestra.ALÇADA-p.alt-20)));
			}
			else {
				vides.add(new Vida(Finestra.AMPLADA,p.alt+20+rng.nextInt(Finestra.ALÇADA-p.alt-20)));
			}
		}
	}
	
	void creaExercit(int t) {
		int index=rng.nextInt((int)((Finestra.ALÇADA-p.alt-50)/60)-1);
		if (t%20==0 && t<=100) {
			for (int i=0;i<(int)((Finestra.ALÇADA-p.alt-50)/60);i++) {
				if (t==60 && i==index) {
					petitesasukes.add(new PetitaAsuka(Finestra.AMPLADA,i*60+10+(int)(p.alt+Finestra.ALÇADA-60*(int)((Finestra.ALÇADA-p.alt-50)/60))/2));
					if (petitesasukes.size()!=0) ((PetitaAsuka)petitesasukes.get(petitesasukes.size()-1)).v_x=-3;
				}
				else {
					enemics.add(new Enemic(Finestra.AMPLADA,i*60+10+(int)(p.alt+Finestra.ALÇADA-60*(int)((Finestra.ALÇADA-p.alt-50)/60))/2));
					((Enemic)enemics.get(enemics.size()-1)).comptador=rng.nextInt(100);
					((Enemic)enemics.get(enemics.size()-1)).trigger=100;
					
				}
			}
		}
	}
	
	void aplicaNivell2(int t) {
		if (t<120) creaExercit(t);
		if (t>=300 && misatos.size()==0) misatos.add(misato);
		if (t==120) {
			for (Nau enemic: enemics) {
				enemic.v_x=0;
				enemic.v_y=3;
			}
			if (petitesasukes.size()!=0) ((PetitaAsuka)petitesasukes.get(petitesasukes.size()-1)).v_x=0;
			if (petitesasukes.size()!=0) ((PetitaAsuka)petitesasukes.get(petitesasukes.size()-1)).v_y=3;
		}
			
		if (t>120) {
			if ((t-120)%20<5) {
				for (Nau enemic: enemics) enemic.v_x=-3;
				if (petitesasukes.size()!=0) ((PetitaAsuka)petitesasukes.get(petitesasukes.size()-1)).v_x=-3;
			}
			if ((t-120)%20==5){
				for (Nau enemic: enemics) {
					enemic.v_x=0;
					enemic.v_y*=-1;
				}
				if (petitesasukes.size()!=0) ((PetitaAsuka)petitesasukes.get(petitesasukes.size()-1)).v_x=0;
				if (petitesasukes.size()!=0) ((PetitaAsuka)petitesasukes.get(petitesasukes.size()-1)).v_y*=-1;
			}
		}
	}
	
	void aplicaNivell3(int t) {
		if (t%20==0) {
			int tipus_enemic=rng.nextInt(100);
			if (tipus_enemic<30) {
				reflectors.add(new Reflector(Finestra.AMPLADA,p.alt+20+rng.nextInt(Finestra.ALÇADA-p.alt-20)));
			}
			
			else if (30<=tipus_enemic && tipus_enemic<60) {
				enemics.add(new Enemic(Finestra.AMPLADA,p.alt+20+rng.nextInt(Finestra.ALÇADA-p.alt-20)));
			}
			else if (60<=tipus_enemic && tipus_enemic<90) {
				clons.add(new Clon(asuka,Finestra.AMPLADA,p.alt+20+rng.nextInt(Finestra.ALÇADA-p.alt-20),fase));
			}
			else {
				vides.add(new Vida(Finestra.AMPLADA,p.alt+20+rng.nextInt(Finestra.ALÇADA-p.alt-20)));
			}
		}
	}
	
	void aplicaNivell4(int t) {
		if (t%30==0 && t%210!=0 && t%210!=30) { 		
			reflectors.add(new Reflector(Finestra.AMPLADA, p.alt-25+(int)((Finestra.ALÇADA-p.alt)/2)));
		}
		if (t%15==0 && t%105!=0 && t%105!=15) {
			reflectors.add(new Reflector(Finestra.AMPLADA, p.alt-25+60+(int)((Finestra.ALÇADA-p.alt)/2)));
			reflectors.get(reflectors.size()-1).v_x=-4;
		}
		if (t%10==0 && t%70!=0 && t%70!=10) { 		
			reflectors.add(new Reflector(Finestra.AMPLADA, p.alt-25-60+(int)((Finestra.ALÇADA-p.alt)/2)));
			reflectors.get(reflectors.size()-1).v_x=-6;
		}
		if (t%80==0) {
			if (rng.nextInt(100)<85) {
				enemics.add(new Enemic(Finestra.AMPLADA, p.alt+20+rng.nextInt(p.alt-25-120+(int)((Finestra.ALÇADA-p.alt)/2)-(p.alt+20))));
			}
			else {
				vides.add(new Vida(Finestra.AMPLADA,p.alt+20+rng.nextInt(p.alt-25-120+(int)((Finestra.ALÇADA-p.alt)/2)-(p.alt+20))));
			}
			if (petitesasukes.size()==0 && asuka.feliços_dijous==0 && feliçosdijous.size()==0) petitesasukes.add(new PetitaAsuka(Finestra.AMPLADA,p.alt+20+rng.nextInt((int)(Finestra.ALÇADA/2)-30-p.alt-20)));
		}
		if (t%40==0) clons.add(new Clon(asuka,Finestra.AMPLADA,570+170*(t%80)/40,fase));
	}
	
	
	void aplicaNivell5(int t) {
		if (t%40==0 && t%80!=0) {
			int tipus_enemic=rng.nextInt(100);
			if (tipus_enemic<90) {
				disparadors.add(new Disparador(asuka,Finestra.AMPLADA,p.alt+20+rng.nextInt(Finestra.ALÇADA-p.alt-20),fase));
			}
			else {
				vides.add(new Vida(Finestra.AMPLADA,p.alt+20+rng.nextInt(Finestra.ALÇADA-p.alt-20)));
			}
		}
		if (t%80==0) {
			int espai=rng.nextInt((int)((Finestra.ALÇADA-p.alt)/60));
			for (int i=0;i<(Finestra.ALÇADA-p.alt)/60+1;i++) {
				if (i!=espai && i!=espai+1) {
					reflectors.add(new Reflector(Finestra.AMPLADA,p.alt+5+i*60));
					reflectors.get(reflectors.size()-1).v_x=-3;
				}
			}
		}
	}
	
	void aplicaNivell6(int t) {
		if (gegants.size()<=0) gegants.add(new Gegant());
		if (shinjis.size()<=0) shinjis.add(shinji=new Shinji());
		if (t%40==0) {
			if (disparadors.size()==0) {
				disparadors.add(new Disparador(asuka,Finestra.AMPLADA,p.alt+5,fase));
				disparadors.add(new Disparador(asuka,Finestra.AMPLADA,Finestra.ALÇADA-60,fase));
			}
			else if (disparadors.size()==1) {
				disparadors.add(new Disparador(asuka,Finestra.AMPLADA,p.alt+5+Finestra.ALÇADA-60-disparadors.get(0).y,6));
			}
			if (petitesasukes.size()==0 && asuka.feliços_dijous<=0) petitesasukes.add(new PetitaAsuka(Finestra.AMPLADA,(int)(Finestra.ALÇADA/2)+150*(2*rng.nextInt(2)-1)));
		}
	}
	
	void comptaNaus() {
		int n=0;
		for (ArrayList<Nau> tipus: naus) {
			n+=tipus.size();
		}
		System.out.println("Numero de naus actual: "+n);
	}
	
	void dispara() {
		for (ArrayList<Nau> tipus_nau: naus) {
			for (Nau nau: tipus_nau) {
				if (nau instanceof Disparable) {
					if (((Disparable) nau).comptar()) projectils.add(((Disparable)nau).disparar());
				}
			}
		}
	}
	
	void moureElements() {
		for (ArrayList<Nau> llista: naus) {
			for (Nau nau: llista) {
				nau.moure();
			}
		}
	}
	
	boolean colideix(Nau nau, Nau nau2) {
		if (nau2.x>nau.x+nau.ample || nau2.x+nau2.ample<nau.x || nau2.y+nau2.alt<nau.y || nau.y+nau.alt<nau2.y) {
			return false;
		}
		else {
			return true;
		}
	}
	
	void eliminaNaus() {
		for (int i=0;i<naus.size();i++) {
			for (int j=0;j<naus.get(i).size();j++) {
				if (naus.get(i).get(j).vida<=0 && !(naus.get(i).get(j) instanceof Asuka)) {
					naus.get(i).remove(j);
					j--;
				}
			}
		}
	}
	
	void colideixNaus() {
		for (int i=0;i<naus.size();i++) {
			for (int j=0; j<naus.get(i).size();j++) {
				for (int k=j+1; k<naus.get(i).size();k++) {
					if (colideix(naus.get(i).get(j),naus.get(i).get(k))) {
						naus.get(i).get(j).reaccionaColisio(naus.get(i).get(k));
						naus.get(i).get(k).reaccionaColisio(naus.get(i).get(j));
					}
				}
				for (int k=i+1;k<naus.size();k++) {
					for (int l=0;l<naus.get(k).size();l++) {
						if (colideix(naus.get(i).get(j),naus.get(k).get(l))) {
							naus.get(i).get(j).reaccionaColisio(naus.get(k).get(l));
							naus.get(k).get(l).reaccionaColisio(naus.get(i).get(j));
						}
					}
				}
			}
		}
	}
	
	void colideixParets() {
		for (int i=1;i<naus.size();i++) {
			for (Nau nau:naus.get(i)) {
				if (nau.x+nau.ample<-10 || nau.x>Finestra.AMPLADA+10 || nau.y>Finestra.ALÇADA+10 || nau.y<p.alt) nau.vida=0;
			}
		}
	}
	
	void detectaColisions() {
		colideixParets();
		colideixNaus();
		eliminaNaus();
	}
	
	void repintaPantalla() {
		fons_x=(fons_x-1)%Finestra.AMPLADA;
		f.g.drawImage(fons,fons_x,fons_y,Finestra.AMPLADA,Finestra.ALÇADA,null);
		f.g.drawImage(fons,fons_x+Finestra.AMPLADA,fons_y,Finestra.AMPLADA,Finestra.ALÇADA,null);
		asuka.pintar(f.g);
		for (ArrayList<Nau> tipus :naus) {
			for (Nau nau: tipus) {
				nau.pintar(f.g);	
			}
		}
		p.escriuPanellDeControl(fase);
		f.revalidate();
		f.repaint();
	}
	
	@Override
	public void keyTyped(KeyEvent e) {
		
	}
	
	@Override
	public void keyPressed(KeyEvent e) {
		if (e.getKeyCode()==KeyEvent.VK_RIGHT) asuka.v_x=7;
		if (e.getKeyCode()==KeyEvent.VK_LEFT) asuka.v_x=-7;
		if (e.getKeyCode()==KeyEvent.VK_UP) asuka.v_y=-7;
		if (e.getKeyCode()==KeyEvent.VK_DOWN) asuka.v_y=7;
		if (e.getKeyCode()==KeyEvent.VK_SPACE && !alerta) projectils.add(asuka.disparar());
		if (e.getKeyCode()==KeyEvent.VK_A && asuka.feliços_dijous>0 && !alerta) {
			feliçosdijous.add(asuka.desitjarFeliçDijous());
			asuka.feliços_dijous--;
		}
	}

	@Override
	public void keyReleased(KeyEvent e) {
		if (e.getKeyCode()==KeyEvent.VK_RIGHT) {
			asuka.v_x=0;
		}
		if (e.getKeyCode()==KeyEvent.VK_LEFT) {
			asuka.v_x=0;
		}
		if (e.getKeyCode()==KeyEvent.VK_UP) {
			asuka.v_y=0;
		}
		if (e.getKeyCode()==KeyEvent.VK_DOWN) {
			asuka.v_y=0;
		}
		if (e.getKeyCode()==KeyEvent.VK_SPACE) {};
	}
	
}
