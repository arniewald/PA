import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Projectil extends Nau{
	
	Nau origen;
	
	Projectil(int x, int y, int v_x, int v_y, Nau origen){
		super(x,y,v_x,v_y,10,10,1,"projectil_enemic.png");
		this.origen=origen;
		if (origen instanceof Asuka) {
			try {
				this.imatge=ImageIO.read(new File("projectil_asuka.png"));
			} catch (IOException e) {
			}
		}
	}

	@Override
	void moure() {
		x+=v_x;
		y+=v_y;
	}

	@Override
	void reaccionaColisio(Nau nau) {
		if (origen instanceof Asuka) {
			if (nau instanceof Reflector) {
				x-=Math.signum(v_x)*10;
				v_x*=-1;
			}
			else if (nau instanceof Projectil || nau instanceof Vida || nau instanceof PetitaAsuka || nau instanceof FeliçDijous) {}
			else if (nau instanceof Enemic || nau instanceof Clon || nau instanceof Disparador) {
				((Asuka)origen).j.puntuacio+=100;
				vida--;
			}
			else {
				vida--;
			}
		}
		else {
			if (nau instanceof Asuka) vida--;
		}
	}
}
