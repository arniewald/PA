
public interface Disparable {
	boolean comptar();
	Projectil disparar();
}
