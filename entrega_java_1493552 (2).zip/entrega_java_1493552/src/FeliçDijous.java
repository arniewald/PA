
public class FeliçDijous extends Nau{

	FeliçDijous(int x, int y) {
		super(x, y, 10, 0, 50, 50, 1, "feliçdijous.png");
	}

	@Override
	void moure() {
		x+=v_x;
	}

	@Override
	void reaccionaColisio(Nau nau) {
		vida--;
	}

}
