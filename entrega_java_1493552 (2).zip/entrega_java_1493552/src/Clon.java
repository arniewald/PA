
public class Clon extends Nau{
	
	Nau objectiu;
	int fase;
	
	Clon(Nau objectiu, int x, int y, int fase){
		super(x,y,8,8,50,50,3, "clon.png");
		this.objectiu=objectiu;
		this.fase=fase;
	}

	@Override
	void moure() {
		if (fase==4) {
			if (objectiu.y<(int)(Finestra.ALÇADA/5)-25+60+(int)((Finestra.ALÇADA-(int)(Finestra.ALÇADA/5))/2)+5) x-=v_x;
			else {
				double dist_x=(objectiu.x+(int)(objectiu.ample/2)-x-(int)(ample/2));
				double dist_y=(objectiu.y+(int)(objectiu.alt/2)-y-(int)(alt/2));
				double dist=Math.sqrt(dist_x*dist_x+dist_y*dist_y);
				if (objectiu.x-x-ample<0) {
					x+=(int)(v_x*dist_x/dist);
					y+=(int)(v_y*dist_y/dist);
					System.out.println((v_x*dist_x/dist)+" "+(v_y*dist_y/dist));
				}
				else {
					x-=v_x;
				}
			}
		}
		else {
			double dist_x=(objectiu.x+(int)(objectiu.ample/2)-x-(int)(ample/2));
			double dist_y=(objectiu.y+(int)(objectiu.alt/2)-y-(int)(alt/2));
			double dist=Math.sqrt(dist_x*dist_x+dist_y*dist_y);
			if (objectiu.x-x-ample<0) {
				x+=(int)(v_x*dist_x/dist);
				y+=(int)(v_y*dist_y/dist);
			}
			else {
				x-=v_x;
			}
		}
	}

	@Override
	void reaccionaColisio(Nau nau) {
		if (nau instanceof Asuka) vida=0;
		if (nau instanceof Projectil && ((Projectil)(nau)).origen instanceof Asuka) vida--;		
	}
	
	
	/*Clon(Contenidor contenidor, int hor, int ver){
		super(contenidor.x+hor+(2+hor)/2*contenidor.ample,contenidor.y+ver+(2+ver)/ver*contenidor.alt,30*hor,30*ver,50,30,1, "clon.png");
	}

	@Override
	void moure() {
		x+=v_x;
		y+=v_y;
		
	}

	@Override
	void reaccionaColisio(Nau nau) {}*/

}
