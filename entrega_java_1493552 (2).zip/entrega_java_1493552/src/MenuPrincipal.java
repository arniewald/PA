import java.awt.Image;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class MenuPrincipal implements MouseListener{
	Finestra f;
	Image portada;
	
	MenuPrincipal(Finestra f){
		this.f=f;
		try {
			portada=ImageIO.read(new File("portada.jpg"));
		} catch (IOException e) {
			e.printStackTrace();
		}	
		f.addMouseListener(this);
		f.g.drawImage(portada,0,0,Finestra.AMPLADA,Finestra.ALÇADA,null);
	}


	@Override
	public void mouseClicked(MouseEvent e) {
		int x=e.getX();
		int y=e.getY();
		if (x>=910 && x<=1060 && y>=380 && y<=440) {
			f.pantalla=1;
			f.removeMouseListener(this);
		}
		if (x>=810 && x<=1260 && y>=460 && y<=520) {
			f.pantalla=2;
			f.removeMouseListener(this);
		}
		if (x>=860 && x<=1110 && y>=550 && y<=605) {
			f.pantalla=3;
			f.removeMouseListener(this);
		}
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	
}
