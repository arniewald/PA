import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JTextField;

public class PanellDeControl  implements MouseListener, KeyListener {
	int x, y, ample, alt;
	Joc j;
	Image pausa, reprendre, sortir, fons_pausa, derrota, victoria;
	Image[] perfils;
	String[] textos;
	int puntuacio;
	JTextField txt;
	
	PanellDeControl(Joc j){
		this.j=j;
		j.f.addMouseListener(this);
		x=0;
		y=0;
		textos=new String[6];
		perfils = new Image[4];
		textos[0]="Feliç dijous Asuka. El nostre primer objectiu és rescatar la Misato. De moment, sobreviu a l'onada d'enemics. Sort!";
		textos[1]="Vet-la aquí! Obten la Petita Asuka i desitja-li Feliç Dijous a la Misato. Només tens una oportunitat!";
		textos[2]="Feliç dijous Asuka, i gràcies per rescatar-me! Ara hem de trobar la Rei. Sobreviu a l'onada d'enemics!";
		textos[3]="Ja la veig! Hauràs d'aconseguir les petites Asukes a dalt de la pantalla i desitjar-li dos cops feliç dijous a baix. Tu pots!";
		textos[4]="Asuka... gràcies. Vigila amb aquests enemics... Saben on disparar. Només queda en Shinji...";
		textos[5]="Un gran enemic s'acosta per darrere. En Shinji és allà. Desitja-li feliç dijous tres cops i tot acabarà.";
		ample=Finestra.AMPLADA;
		alt=(int)(Finestra.ALÇADA/5);
		try {
			perfils[0]=ImageIO.read(new File("ritsuko.jpg"));
			perfils[1]=ImageIO.read(new File("misato_feliç.png"));
			perfils[2]=ImageIO.read(new File("rei_feliç.jpg"));
			perfils[3]=ImageIO.read(new File("shinji_feliç.jpg"));
			pausa=ImageIO.read(new File("pausa.png"));
			reprendre=ImageIO.read(new File("reprendre.png"));
			fons_pausa=ImageIO.read(new File("fons_pausa.jpg"));
			derrota=ImageIO.read(new File("derrota.png"));
			sortir=ImageIO.read(new File("sortir.png"));
			victoria=ImageIO.read(new File("victoria.png"));
		} catch (IOException e) {
		}
		txt=null;
	}
	
	void escriuPanellDeControl(int fase) {
		j.f.g.setColor(Color.gray);
		j.f.g.fillRect(x,y,ample,alt);
		if (j.estat!=4) j.f.g.drawImage(perfils[(fase-1)/2], 20, (int)(alt*0.2), 120, (int)(alt*0.6), null);
		else j.f.g.drawImage(perfils[3], 20, (int)(alt*0.2), 120, (int)(alt*0.6), null);
		j.f.g.setColor(Color.green);
		j.f.g.setFont(new Font("Consolas", Font.PLAIN, 20));
		j.f.g.drawString("TEMPS (s): "+Integer.toString(j.temps/1000), (int)(alt*0.2)+140,(int)(alt*0.8)-20);
		j.f.g.drawString("PUNTUACIÓ: "+Integer.toString(j.puntuacio), (int)(alt*0.2)+140,(int)(alt*0.8));
		if (j.estat!=2 && j.estat!=4) j.f.g.drawImage(pausa, (int)(Finestra.AMPLADA*0.9), (int)(alt*0.6), (int)(alt*0.2), (int)(alt*0.2), null);
		if (j.estat==0) {
			j.f.g.drawString(textos[fase-1], (int)(alt*0.2)+140,(int)(alt*0.4));
		}
		if (j.estat==1) {
			j.f.g.setFont(new Font("Consolas", Font.PLAIN, 60));
			j.f.g.drawString("Derrota :(", (int)(alt*0.2)+620,(int)(alt*0.5));
			j.f.g.setFont(new Font("Consolas", Font.PLAIN, 30));
			j.f.g.drawString("Reintentar          Sortir", (int)(alt*0.2)+550,(int)(alt*0.9));
			j.f.g.drawImage(derrota, (int)(Finestra.AMPLADA*0.25), (int)(Finestra.ALÇADA*0.25), (int)(Finestra.AMPLADA*0.5), (int)(Finestra.ALÇADA*0.65), null);
		}
		if (j.estat==2) {
			j.f.g.setFont(new Font("Consolas", Font.PLAIN, 120));
			j.f.g.drawString("PAUSA", (int)(alt*0.2)+500,(int)(alt*0.8));
			j.f.g.drawImage(reprendre, (int)(Finestra.AMPLADA*0.9), (int)(alt*0.6), (int)(alt*0.2), (int)(alt*0.2), null);
			j.f.g.drawImage(fons_pausa, (int)(Finestra.AMPLADA*0.25), (int)(Finestra.ALÇADA*0.25), (int)(Finestra.AMPLADA*0.5), (int)(Finestra.ALÇADA*0.65), null);
		}
		if (j.estat==3) {
			j.f.g.setFont(new Font("Consolas", Font.PLAIN, 60));
			j.f.g.drawString("Vols abandonar la partida?", (int)(alt*0.2)+350,(int)(alt*0.5));
			j.f.g.drawString("SÍ          NO", (int)(alt*0.2)+550,(int)(alt*0.9));
		}
		if (j.estat==4) {
			j.f.g.setFont(new Font("Consolas", Font.PLAIN, 60));
			j.f.g.drawString("Enhorabona!!", (int)(alt*0.2)+620,(int)(alt*0.5));
			j.f.g.drawImage(victoria, 0, alt, Finestra.AMPLADA, Finestra.ALÇADA-alt, null);
			
		}
		j.f.g.drawImage(sortir, (int)(Finestra.AMPLADA*0.95), (int)(alt*0.6), (int)(alt*0.2), (int)(alt*0.2), null);
	}

	
	
	@Override
	public void mouseClicked(MouseEvent e) {
		int x=e.getX();
		int y=e.getY();
		if (j.estat==0) {
			if (x>(int)(Finestra.AMPLADA*0.9) && x<(int)(Finestra.AMPLADA*0.9)+(int)(alt*0.2) && y>(int)(alt*0.6) && y<(int)(alt*0.6)+(int)(alt*0.2)) {
				j.estat=2;
			}
			if (j.estat==0 && x>(int)(Finestra.AMPLADA*0.95) && x<(int)(Finestra.AMPLADA*0.95)+(int)(alt*0.2) && y>(int)(alt*0.6) && y<(int)(alt*0.6)+(int)(alt*0.2)) {
				j.estat=3;
			}
		}
		else if (j.estat==1) {
			if (x>(int)(alt*0.2)+550 && x<(int)(alt*0.2)+720 && y>(int)(alt*0.9)-30 && y<(int)(alt*0.9)+10) {
				j.reinicialitzacio();
				j.f.addKeyListener(j);
				j.estat=0;
			}
			if (x>(int)(alt*0.2)+880 && x<(int)(alt*0.2)+1000 && y>(int)(alt*0.9)-30 && y<(int)(alt*0.9)+10) {
				j.estat=0;
				j.f.pantalla=0;
			}
		}
		else if (j.estat==2) {
			if (x>(int)(Finestra.AMPLADA*0.9) && x<(int)(Finestra.AMPLADA*0.9)+(int)(alt*0.2) && y>(int)(alt*0.6) && y<(int)(alt*0.6)+(int)(alt*0.2)) {
				j.f.addKeyListener(j);
				j.estat=0;
			}
		}
		else if (j.estat==3) {
			if (x>(int)(alt*0.2)+550 && x<(int)(alt*0.2)+610 && y>(int)(alt*0.9)-50 && y<(int)(alt*0.9)+10) {
				j.f.pantalla=0;
			}
			else if (x>(int)(alt*0.2)+950 && x<(int)(alt*0.2)+1010 && y>(int)(alt*0.9)-50 && y<(int)(alt*0.9)+10) {
				j.f.addKeyListener(j);
				j.estat=0;
			}
		}
		else if (j.estat==4) {
			if (x>(int)(Finestra.AMPLADA*0.95) && x<(int)(Finestra.AMPLADA*0.95)+(int)(alt*0.2) && y>(int)(alt*0.6) && y<(int)(alt*0.6)+(int)(alt*0.2)) j.f.pantalla=0;
		}
		escriuPanellDeControl(j.fase);
		j.repintaPantalla();
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
}
