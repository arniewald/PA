import java.awt.FlowLayout;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class GuardaPartida extends JFrame implements ActionListener{
	int puntuacio, temps;
	String nom;
	TextField txt;
	JButton boto;
	JLabel alerta;
	
	GuardaPartida(int puntuacio, int temps){
		super("Guarda la partida!");
		this.puntuacio=puntuacio;
		this.temps=temps;
		setSize(500,500);
		setLayout(new FlowLayout());
		setVisible(true);
		txt=new TextField(20);
		boto=new JButton("Guardar");
		boto.addActionListener(this);
		add(txt);
		add(boto);
		alerta = new JLabel("No més de 20 caracters!"); 
		alerta.setBounds(50,100, 100,30);
		this.add(alerta);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource()==boto && txt.getText().length()!=0 && txt.getText().length()<=20) {
			String nom=txt.getText();
			Connection con;
			try {
				con=DriverManager.getConnection("jdbc:sqlite:partides.db");
				Statement smt=con.createStatement();
				String q="INSERT INTO partides(jugadora,puntuacio,temps) VALUES(\""+nom+"\","+Integer.toString(puntuacio)+","+Integer.toString(temps/1000)+");";
				smt.executeUpdate(q);
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			dispose();
		}
		
	}
}