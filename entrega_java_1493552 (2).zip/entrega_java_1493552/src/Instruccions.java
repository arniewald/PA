import java.awt.Image;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Instruccions implements MouseListener{
	Finestra f;
	Image instruccions, sortir;
	
	Instruccions(Finestra f){
		this.f=f;
		try {
			instruccions=ImageIO.read(new File("instruccions.png"));
			sortir=ImageIO.read(new File("sortir.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		f.addMouseListener(this);
		f.g.drawImage(instruccions,0,0,Finestra.AMPLADA,Finestra.ALÇADA,null);
		f.g.drawImage(sortir, (int)(Finestra.AMPLADA*0.93), (int)(Finestra.ALÇADA*0.07), 50, 50, null);
	}
	
	@Override
	public void mouseClicked(MouseEvent e) {
		int x=e.getX();
		int y=e.getY();
		if (x>=(int)(Finestra.AMPLADA*0.93) && x<=(int)(Finestra.AMPLADA*0.93)+50 && y>=(int)(Finestra.ALÇADA*0.07) && y<=(int)(Finestra.ALÇADA*0.07)+50) {
			f.pantalla=0;
			f.removeMouseListener(this);
		}
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
}
