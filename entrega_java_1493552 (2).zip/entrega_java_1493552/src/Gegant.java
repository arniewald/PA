
public class Gegant extends Nau{

	Gegant() {
		super(-1500,(int)(800/5), 1, 0, 1500, (int)(4*800/5), 1, "gegant2.jpg");
	}

	@Override
	void moure() {
		x+=v_x;
		
	}

	@Override
	void reaccionaColisio(Nau nau) {
	}

}
